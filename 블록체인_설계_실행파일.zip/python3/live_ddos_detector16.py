import subprocess
import time
import ipaddress
import shutil
import threading
import queue
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

import requests
import urllib3
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse
import joblib
import numpy as np
import pandas as pd
from PIL import Image, ImageTk, ImageFilter, ImageEnhance

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# =========================================
# User configuration
# =========================================

INTERFACE = "any"
WINDOW_SECONDS = 20
SLEEP_BETWEEN_LOOPS = 1

BASE_DIR = Path(__file__).resolve().parent

MODEL_PATH = BASE_DIR / "isolation_forest_model1.pkl"
SCALER_PATH = BASE_DIR / "scaler1.pkl"

CICFLOWMETER_CMD = "cicflowmeter"

WORK_DIR = BASE_DIR / "live_monitor"
RAW_PCAP_DIR = WORK_DIR / "raw_pcap"
RAW_CSV_DIR = WORK_DIR / "raw_csv"
SELECTED_CSV_DIR = WORK_DIR / "selected_csv"
RESULT_DIR = WORK_DIR / "results"

BLACKLIST_FILE = BASE_DIR / "black_ip.txt"
BACKGROUND_IMAGE = BASE_DIR / "kali_santa.png"

MIN_PCAP_SIZE = 5000

# Temporary auto-block settings
IPSET_NAME = "temp_blacklist"
TEMP_BLOCK_SECONDS = 300
AUTO_BLOCK_ENABLED = True

# =========================================
# XSS target URL scan settings
# =========================================
# This version does NOT use a proxy and does NOT start a local test server.
# It reads only one target URL from:
# /home/kali/cicflowmeter/target_url.txt
#
# Example target_url.txt:
# http://127.0.0.1:5000
#
TARGET_URL_FILE = BASE_DIR / "target_url.txt"
XSS_SCAN_INTERVAL = 5

XSS_ALERT_MESSAGE = "xss!xss!xss!xss!xss!xss!xss!xss!xss!xss!xss!xss!"
XSS_ALERT_COLOR = "#6a1b9a"

XSS_PATTERNS = [
    "<script",
    "javascript:",
    "onerror=",
    "onload=",
    "onclick=",
    "onmouseover=",
    "alert(",
    "document.cookie",
    "<iframe",
    "<svg",
    "<object",
    "<embed",
    "eval(",
    "fromcharcode",
]

# =========================================
# CSRF target URL scan settings
# =========================================
# This CSRF detector does NOT submit dangerous POST requests.
# It downloads the target page and checks HTML forms.
# Detection logic:
# - POST form exists
# - form action looks sensitive
# - CSRF token field is missing
# - SameSite cookie protection is missing or weak
CSRF_SCAN_INTERVAL = 5
CSRF_ALERT_COLOR = "#ef6c00"
CSRF_ALERT_MESSAGE = "csrf!csrf!csrf!csrf!csrf!csrf!csrf!csrf!csrf!csrf!csrf!csrf!"

CSRF_TOKEN_KEYWORDS = [
    "csrf",
    "xsrf",
    "token",
    "authenticity_token",
    "_token",
]

CSRF_SENSITIVE_KEYWORDS = [
    "transfer",
    "pay",
    "payment",
    "delete",
    "remove",
    "update",
    "edit",
    "change",
    "password",
    "admin",
    "logout",
    "withdraw",
    "send",
]


# =========================================
# Clickjacking target URL scan settings
# =========================================
# This detector checks whether the target page has anti-clickjacking protection.
# Detection logic:
# - Missing X-Frame-Options header
# - Missing Content-Security-Policy frame-ancestors directive
# - Page contains iframe tags
# - Hidden/transparent iframe style exists
CLICKJACKING_SCAN_INTERVAL = 5
CLICKJACKING_ALERT_COLOR = "#ad1457"
CLICKJACKING_ALERT_MESSAGE = "clickjacking!clickjacking!clickjacking!clickjacking!"

CLICKJACKING_IFRAME_PATTERNS = [
    "<iframe",
    "opacity:0",
    "opacity: 0",
    "visibility:hidden",
    "visibility: hidden",
    "display:none",
    "display: none",
    "z-index",
    "position:absolute",
    "position: absolute",
]

IMPORTANT_FEATURES = [
    "protocol",
    "flow_duration",
    "flow_byts_s",
    "flow_pkts_s",
    "fwd_pkts_s",
    "bwd_pkts_s",
    "tot_fwd_pkts",
    "tot_bwd_pkts",
    "totlen_fwd_pkts",
    "totlen_bwd_pkts",
    "fwd_pkt_len_mean",
    "bwd_pkt_len_mean",
    "pkt_len_mean",
    "pkt_len_std",
    "pkt_size_avg",
    "flow_iat_mean",
    "flow_iat_std",
    "fwd_iat_mean",
    "bwd_iat_mean",
    "syn_flag_cnt",
]

GUI_WIDTH = 1100
GUI_HEIGHT = 720


# =========================================
# Utility functions
# =========================================
def ensure_dirs():
    for d in [WORK_DIR, RAW_PCAP_DIR, RAW_CSV_DIR, SELECTED_CSV_DIR, RESULT_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def now_tag():
    return time.strftime("%Y%m%d_%H%M%S")


def load_artifacts():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"Model file not found: {MODEL_PATH}")
    if not SCALER_PATH.exists():
        raise FileNotFoundError(f"Scaler file not found: {SCALER_PATH}")

    model = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    return model, scaler


def run_cmd(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


# =========================================
# Firewall / temporary block
# =========================================
def ensure_firewall_setup(log_func):
    global AUTO_BLOCK_ENABLED

    if not AUTO_BLOCK_ENABLED:
        return

    if shutil.which("ipset") is None:
        log_func("[WARNING] ipset is not installed. Auto block disabled.")
        AUTO_BLOCK_ENABLED = False
        return

    if shutil.which("iptables") is None:
        log_func("[WARNING] iptables is not installed. Auto block disabled.")
        AUTO_BLOCK_ENABLED = False
        return

    cmd_create_set = [
        "ipset", "create", IPSET_NAME,
        "hash:ip", "timeout", str(TEMP_BLOCK_SECONDS),
        "-exist"
    ]
    result = run_cmd(cmd_create_set)
    if result.returncode != 0:
        log_func("[WARNING] Failed to create ipset. Auto block disabled.")
        if result.stderr.strip():
            log_func(result.stderr.strip())
        AUTO_BLOCK_ENABLED = False
        return

    cmd_check_rule = [
        "iptables", "-C", "INPUT",
        "-m", "set", "--match-set", IPSET_NAME, "src",
        "-j", "DROP"
    ]
    result = run_cmd(cmd_check_rule)

    if result.returncode != 0:
        cmd_insert_rule = [
            "iptables", "-I", "INPUT", "1",
            "-m", "set", "--match-set", IPSET_NAME, "src",
            "-j", "DROP"
        ]
        result2 = run_cmd(cmd_insert_rule)
        if result2.returncode != 0:
            log_func("[WARNING] Failed to insert iptables rule. Auto block disabled.")
            if result2.stderr.strip():
                log_func(result2.stderr.strip())
            AUTO_BLOCK_ENABLED = False
            return


def is_blockable_ip(ip_str: str) -> bool:
    try:
        ip_obj = ipaddress.ip_address(ip_str)
    except ValueError:
        return False

    if ip_obj.is_loopback:
        return False
    if ip_obj.is_multicast:
        return False
    if ip_obj.is_unspecified:
        return False
    if ip_obj.is_reserved:
        return False

    return True


def temp_block_ips(ips, log_func):
    if not AUTO_BLOCK_ENABLED:
        log_func("[INFO] Auto block is disabled.")
        return []

    blocked = []

    for ip in sorted(ips):
        if not is_blockable_ip(ip):
            continue

        cmd = [
            "ipset", "add", IPSET_NAME, ip,
            "timeout", str(TEMP_BLOCK_SECONDS),
            "-exist"
        ]
        result = run_cmd(cmd)

        if result.returncode == 0:
            blocked.append(ip)
        else:
            log_func(f"[WARNING] Failed to temporarily block IP: {ip}")
            if result.stderr.strip():
                log_func(result.stderr.strip())

    if blocked:
        log_func(f"[INFO] Temporarily blocked {len(blocked)} IP(s) for {TEMP_BLOCK_SECONDS} seconds")
        log_func(f"[INFO] Blocked IP list: {blocked}")
    else:
        log_func("[INFO] No valid IPs were added to temporary block list.")

    return blocked


# =========================================
# XSS target URL scan
# =========================================
def load_target_url(log_func):
    if not TARGET_URL_FILE.exists():
        log_func(f"[WARNING] target_url.txt not found: {TARGET_URL_FILE.resolve()}")
        log_func("[INFO] Create it with: echo 'http://127.0.0.1:5000' > target_url.txt")
        return None

    try:
        url = TARGET_URL_FILE.read_text(encoding="utf-8").strip()

        if not url:
            log_func("[WARNING] target_url.txt is empty.")
            return None

        if not (url.startswith("http://") or url.startswith("https://")):
            log_func("[WARNING] target_url.txt must start with http:// or https://")
            return None

        return url

    except Exception as e:
        log_func(f"[WARNING] Failed to read target_url.txt: {e}")
        return None


def check_target_url_for_xss(log_func):
    url = load_target_url(log_func)

    if not url:
        return False, None, []

    try:
        response = requests.get(
            url,
            timeout=5,
            verify=False,
            headers={"User-Agent": "Mozilla/5.0"}
        )

        html = response.text.lower()
        detected_patterns = []

        for pattern in XSS_PATTERNS:
            if pattern in html:
                detected_patterns.append(pattern)

        if detected_patterns:
            return True, url, detected_patterns

        return False, url, []

    except Exception:
        # Do not spam connection refused warnings when the target URL is offline.
        # Just silently ignore unreachable targets.
        return False, url, []


# =========================================
# CSRF target URL scan
# =========================================
class HTMLFormParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.forms = []
        self.current_form = None

    def handle_starttag(self, tag, attrs):
        attrs_dict = {str(k).lower(): str(v).lower() if v is not None else "" for k, v in attrs}

        if tag.lower() == "form":
            self.current_form = {
                "method": attrs_dict.get("method", "get"),
                "action": attrs_dict.get("action", ""),
                "inputs": [],
            }

        elif tag.lower() == "input" and self.current_form is not None:
            self.current_form["inputs"].append(attrs_dict)

    def handle_endtag(self, tag):
        if tag.lower() == "form" and self.current_form is not None:
            self.forms.append(self.current_form)
            self.current_form = None


def _form_has_csrf_token(form):
    for input_tag in form.get("inputs", []):
        input_name = input_tag.get("name", "")
        input_id = input_tag.get("id", "")
        input_value = input_tag.get("value", "")
        combined = f"{input_name} {input_id} {input_value}".lower()

        for keyword in CSRF_TOKEN_KEYWORDS:
            if keyword in combined:
                return True

    return False


def _is_sensitive_action(action_url):
    action_lower = action_url.lower()
    return any(keyword in action_lower for keyword in CSRF_SENSITIVE_KEYWORDS)


def _has_strong_samesite_cookie(response):
    cookie_headers = []

    try:
        raw_headers = response.raw.headers
        if hasattr(raw_headers, "get_all"):
            cookie_headers = raw_headers.get_all("Set-Cookie") or []
    except Exception:
        cookie_headers = []

    if not cookie_headers:
        header_value = response.headers.get("Set-Cookie", "")
        if header_value:
            cookie_headers = [header_value]

    if not cookie_headers:
        return False

    for cookie in cookie_headers:
        cookie_lower = cookie.lower()
        if "samesite=strict" in cookie_lower or "samesite=lax" in cookie_lower:
            return True

    return False


def check_target_url_for_csrf(log_func):
    url = load_target_url(log_func)

    if not url:
        return False, None, []

    try:
        response = requests.get(
            url,
            timeout=5,
            verify=False,
            headers={"User-Agent": "Mozilla/5.0"}
        )

        html = response.text
        parser = HTMLFormParser()
        parser.feed(html)

        detected_reasons = []
        strong_samesite = _has_strong_samesite_cookie(response)

        for index, form in enumerate(parser.forms, start=1):
            method = form.get("method", "get").lower()
            action = form.get("action", "")
            absolute_action = urljoin(url, action)
            parsed_action = urlparse(absolute_action)
            action_path = parsed_action.path.lower()

            if method != "post":
                continue

            has_token = _form_has_csrf_token(form)
            sensitive = _is_sensitive_action(action_path)

            risk_score = 0
            reasons = []

            risk_score += 30
            reasons.append(f"POST form detected: form #{index}")

            if sensitive:
                risk_score += 30
                reasons.append(f"Sensitive form action detected: {action_path}")

            if not has_token:
                risk_score += 30
                reasons.append("Missing CSRF token field")

            if not strong_samesite:
                risk_score += 10
                reasons.append("Missing or weak SameSite cookie protection")

            if risk_score >= 60:
                detected_reasons.append({
                    "form_index": index,
                    "action": absolute_action,
                    "score": risk_score,
                    "reasons": reasons,
                })

        if detected_reasons:
            return True, url, detected_reasons

        return False, url, []

    except Exception:
        return False, url, []



# =========================================
# Clickjacking target URL scan
# =========================================
def _has_x_frame_options(response):
    value = response.headers.get("X-Frame-Options", "")
    value_lower = value.lower().strip()
    if not value_lower:
        return False, "Missing X-Frame-Options header"

    if "deny" in value_lower or "sameorigin" in value_lower:
        return True, f"X-Frame-Options is set: {value}"

    return False, f"Weak X-Frame-Options value: {value}"


def _has_frame_ancestors_csp(response):
    value = response.headers.get("Content-Security-Policy", "")
    value_lower = value.lower()

    if not value_lower:
        return False, "Missing Content-Security-Policy header"

    if "frame-ancestors" not in value_lower:
        return False, "Missing CSP frame-ancestors directive"

    if "frame-ancestors 'none'" in value_lower or "frame-ancestors 'self'" in value_lower:
        return True, f"CSP frame-ancestors is set: {value}"

    return False, f"Weak CSP frame-ancestors directive: {value}"


def check_target_url_for_clickjacking(log_func):
    url = load_target_url(log_func)

    if not url:
        return False, None, []

    try:
        response = requests.get(
            url,
            timeout=5,
            verify=False,
            headers={"User-Agent": "Mozilla/5.0"}
        )

        html_lower = response.text.lower()
        detected_reasons = []
        risk_score = 0

        has_xfo, xfo_reason = _has_x_frame_options(response)
        has_csp_frame, csp_reason = _has_frame_ancestors_csp(response)

        if not has_xfo:
            risk_score += 35
            detected_reasons.append(xfo_reason)

        if not has_csp_frame:
            risk_score += 35
            detected_reasons.append(csp_reason)

        iframe_patterns = []
        for pattern in CLICKJACKING_IFRAME_PATTERNS:
            if pattern in html_lower:
                iframe_patterns.append(pattern)

        if "<iframe" in iframe_patterns:
            risk_score += 20
            detected_reasons.append("iframe tag exists in page")

        hidden_patterns = [p for p in iframe_patterns if p != "<iframe"]
        if hidden_patterns:
            risk_score += 20
            detected_reasons.append(f"Suspicious hidden/overlay style patterns: {hidden_patterns}")

        # If both major anti-clickjacking headers are missing, it is risky even without iframe.
        # If iframe/overlay patterns also exist, risk becomes stronger.
        if risk_score >= 60:
            finding = {
                "score": risk_score,
                "x_frame_options": response.headers.get("X-Frame-Options", ""),
                "content_security_policy": response.headers.get("Content-Security-Policy", ""),
                "reasons": detected_reasons,
            }
            return True, url, [finding]

        return False, url, []

    except Exception:
        return False, url, []

# =========================================
# Capture / Convert / Predict
# =========================================
def capture_pcap(interface: str, duration: int, out_pcap: Path, log_func):
    log_func(f"[INFO] Start capturing on {interface} for {duration} seconds")

    cmd = [
        "timeout", str(duration),
        "tcpdump",
        "-i", interface,
        "-n",
        "not", "arp",
        "-w", str(out_pcap.resolve())
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.stdout.strip():
        log_func(result.stdout.strip())
    if result.stderr.strip():
        log_func(result.stderr.strip())

    if result.returncode not in (0, 124):
        raise RuntimeError(
            f"tcpdump execution failed\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )

    if not out_pcap.exists():
        raise RuntimeError("pcap file was not created.")

    pcap_size = out_pcap.stat().st_size
    log_func(f"[INFO] pcap saved -> {out_pcap.resolve()} ({pcap_size} bytes)")

    if pcap_size < MIN_PCAP_SIZE:
        log_func("[WARNING] pcap too small, probably no useful traffic")
        return False

    return True


def convert_pcap_to_csv(pcap_path: Path, csv_path: Path, log_func):
    cmd = [
        CICFLOWMETER_CMD,
        "-f",
        str(pcap_path.resolve()),
        "-c",
        str(csv_path.resolve())
    ]

    log_func(f"[INFO] cicflowmeter conversion started -> {csv_path.name}")
    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.stdout.strip():
        log_func("[DEBUG] STDOUT:")
        log_func(result.stdout.strip())

    if result.stderr.strip():
        log_func("[DEBUG] STDERR:")
        log_func(result.stderr.strip())

    if result.returncode != 0:
        raise RuntimeError(
            f"cicflowmeter conversion failed\n"
            f"CMD: {' '.join(cmd)}\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )

    if not csv_path.exists():
        raise RuntimeError("flow CSV file was not created.")

    if csv_path.stat().st_size == 0:
        raise RuntimeError("flow CSV file was created but is empty.")

    log_func(f"[INFO] raw flow csv saved -> {csv_path.resolve()}")


def select_features(input_csv: Path, output_csv: Path, log_func) -> pd.DataFrame:
    df = pd.read_csv(input_csv)

    df.columns = [str(col).strip().lower() for col in df.columns]
    log_func(f"[DEBUG] raw csv columns: {list(df.columns)}")

    existing_features = [f for f in IMPORTANT_FEATURES if f in df.columns]

    if not existing_features:
        raise RuntimeError("None of the selected features were found in raw CSV.")

    df_selected = df[existing_features].copy()

    df_selected = df_selected.apply(pd.to_numeric, errors="coerce")
    df_selected = df_selected.replace([np.inf, -np.inf], np.nan)

    for col in df_selected.columns:
        if df_selected[col].isna().all():
            df_selected[col] = 0
        else:
            df_selected[col] = df_selected[col].fillna(df_selected[col].median())

    df_selected.to_csv(output_csv.resolve(), index=False)

    log_func(f"[INFO] selected feature csv saved -> {output_csv.resolve()}")
    log_func(f"[INFO] selected feature count: {len(existing_features)}")

    return df_selected


def align_features_for_scaler(df_selected: pd.DataFrame, scaler) -> pd.DataFrame:
    if hasattr(scaler, "feature_names_in_"):
        required_features = [str(c).strip().lower() for c in scaler.feature_names_in_]
    else:
        required_features = IMPORTANT_FEATURES

    aligned = df_selected.copy()

    for col in required_features:
        if col not in aligned.columns:
            aligned[col] = 0

    aligned = aligned[required_features]
    return aligned


def predict_with_model(df_selected: pd.DataFrame, raw_df: pd.DataFrame, model, scaler):
    X = align_features_for_scaler(df_selected, scaler)
    X_scaled = scaler.transform(X)

    preds = model.predict(X_scaled)
    scores = model.decision_function(X_scaled)

    result_df = raw_df.copy()
    result_df["prediction"] = preds
    result_df["anomaly_score"] = scores
    result_df["label_text"] = result_df["prediction"].map({1: "NORMAL", -1: "ANOMALY"})

    anomaly_df = result_df[result_df["prediction"] == -1].copy()

    anomaly_count = int((preds == -1).sum())
    total_count = len(result_df)
    ratio = anomaly_count / total_count if total_count > 0 else 0.0

    return result_df, anomaly_df, anomaly_count, total_count, ratio


def extract_anomaly_ips(anomaly_df: pd.DataFrame):
    ips = set()

    possible_src_columns = [
        "src_ip",
        "source_ip",
    ]

    found_col = None
    for col in possible_src_columns:
        if col in anomaly_df.columns:
            found_col = col
            break

    if found_col is None:
        return ips

    values = anomaly_df[found_col].dropna().astype(str).str.strip()

    for ip in values:
        if ip and ip.lower() != "nan":
            ips.add(ip)

    return ips


def save_blacklist_log(ips, log_func):
    existing = set()

    if BLACKLIST_FILE.exists():
        with open(BLACKLIST_FILE, "r", encoding="utf-8") as f:
            existing = {line.strip() for line in f if line.strip()}

    new_ips = ips - existing

    if not new_ips:
        log_func("[INFO] No new suspicious IPs to add to black_ip.txt")
        return []

    with open(BLACKLIST_FILE, "a", encoding="utf-8") as f:
        for ip in sorted(new_ips):
            f.write(ip + "\n")

    log_func(f"[INFO] {len(new_ips)} new IP(s) added to {BLACKLIST_FILE.resolve()}")
    return sorted(new_ips)


# =========================================
# GUI App
# =========================================
class DDoSDetectorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("AI DDoS Detector GUI")
        self.root.geometry(f"{GUI_WIDTH}x{GUI_HEIGHT}")
        self.root.minsize(1000, 650)

        self.model = None
        self.scaler = None
        self.running = False
        self.worker_thread = None
        self.xss_thread = None
        self.csrf_thread = None
        self.clickjacking_thread = None
        self.xss_monitor_running = True
        self.csrf_monitor_running = True
        self.clickjacking_monitor_running = True
        self.gui_queue = queue.Queue()
        self.xss_alert_count = 0
        self.csrf_alert_count = 0
        self.clickjacking_alert_count = 0
        self.last_xss_state = False
        self.last_csrf_state = False
        self.last_clickjacking_state = False
        self.xss_alerted_urls = set()
        self.csrf_alerted_urls = set()
        self.clickjacking_alerted_urls = set()

        self.canvas = None
        self.bg_original = None
        self.bg_img = None
        self.bg_image_id = None

        self.status_box_id = None
        self.info_box_id = None
        self.log_box_id = None
        self.ip_box_id = None

        self.status_title_id = None
        self.status_detail_id = None
        self.info_text_id = None

        self.title_id = None
        self.total_box_id = None
        self.anomaly_box_id = None
        self.ratio_box_id = None
        self.total_value_id = None
        self.anomaly_value_id = None
        self.ratio_value_id = None

        self.start_button = None
        self.stop_button = None
        self.clear_button = None
        self.log_text = None
        self.ip_listbox = None

        self._build_ui()
        self.root.after(200, self.process_gui_queue)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.bind("<Configure>", self.on_resize)

        # XSS monitor will start only after Start Detection button is pressed.
        # It will not scan target_url.txt when the GUI is just opened.

    # =====================================
    # Background
    # =====================================
    def _load_background(self):
        if not BACKGROUND_IMAGE.exists():
            raise FileNotFoundError(f"Background image not found: {BACKGROUND_IMAGE}")
        self.bg_original = Image.open(BACKGROUND_IMAGE).convert("RGB")

    def _create_processed_background(self, width, height):
        img = self.bg_original.resize((width, height))
        img = img.filter(ImageFilter.GaussianBlur(radius=7))

        darkener = ImageEnhance.Brightness(img)
        img = darkener.enhance(0.55)

        contrast = ImageEnhance.Contrast(img)
        img = contrast.enhance(1.1)

        return ImageTk.PhotoImage(img)

    def _draw_background(self, width, height):
        self.bg_img = self._create_processed_background(width, height)

        if self.bg_image_id is None:
            self.bg_image_id = self.canvas.create_image(
                0, 0, image=self.bg_img, anchor="nw"
            )
        else:
            self.canvas.itemconfig(self.bg_image_id, image=self.bg_img)
            self.canvas.coords(self.bg_image_id, 0, 0)

        self.canvas.tag_lower(self.bg_image_id)

    # =====================================
    # UI build
    # =====================================
    def _build_ui(self):
        self._load_background()

        self.canvas = tk.Canvas(
            self.root,
            highlightthickness=0,
            bd=0
        )
        self.canvas.pack(fill="both", expand=True)

        self._draw_background(GUI_WIDTH, GUI_HEIGHT)
        self._draw_static_ui(GUI_WIDTH, GUI_HEIGHT)
        self._create_widgets(GUI_WIDTH, GUI_HEIGHT)

    def _draw_panel(self, x1, y1, x2, y2, outline="#c0c0c0"):
        rect_id = self.canvas.create_rectangle(
            x1, y1, x2, y2,
            fill="#1c1c1c",
            outline=outline,
            width=1,
            stipple="gray50"
        )
        return rect_id

    def _draw_static_ui(self, width, height):
        self.canvas.delete("ui_static")

        # Title
        self.title_bg_id = self.canvas.create_rectangle(
            width // 2 - 430, 28, width // 2 + 430, 78,
            fill="#111111", outline="#d9d9d9", width=1, stipple="gray50",
            tags="ui_static"
        )
        self.title_id = self.canvas.create_text(
            width // 2, 53,
            text="AI-Based DDoS / XSS / CSRF / Clickjacking Detection System",
            fill="white",
            font=("Arial", 20, "bold"),
            tags="ui_static"
        )

        # Top panels
        self.status_box_id = self.canvas.create_rectangle(
            15, 92, width // 2 - 8, 225,
            fill="#1c1c1c", outline="#d0d0d0", width=1, stipple="gray50",
            tags="ui_static"
        )
        self.info_box_id = self.canvas.create_rectangle(
            width // 2 + 8, 92, width - 15, 225,
            fill="#1c1c1c", outline="#d0d0d0", width=1, stipple="gray50",
            tags="ui_static"
        )

        self.status_title_id = self.canvas.create_text(
            width // 4, 124,
            text="Status: Idle",
            fill="white",
            font=("Arial", 18, "bold"),
            tags="ui_static"
        )
        self.status_detail_id = self.canvas.create_text(
            width // 4, 175,
            text="Normal / Warning / Critical / XSS / CSRF / Clickjacking status will be shown here.",
            fill="white",
            font=("Arial", 12),
            tags="ui_static"
        )

        info_text = (
            f"Interface: {INTERFACE}\n"
            f"Capture Duration: {WINDOW_SECONDS} sec\n"
            f"Auto Block: {'ON' if AUTO_BLOCK_ENABLED else 'OFF'}\n"
            f"Block Duration: {TEMP_BLOCK_SECONDS} sec\n"
            f"Blacklist File: {BLACKLIST_FILE}\n"
            f"XSS Target File: {TARGET_URL_FILE}\n"
            f"CSRF Target File: {TARGET_URL_FILE}\n"
            f"Clickjacking Target File: {TARGET_URL_FILE}"
        )

        self.info_text_id = self.canvas.create_text(
            width // 2 + 25, 157,
            text=info_text,
            fill="white",
            font=("Arial", 12),
            anchor="w",
            justify="left",
            tags="ui_static"
        )

        # Stats boxes
        stat_y1 = 285
        stat_y2 = 350
        margin = 15
        gap = 12
        total_w = width - 2 * margin
        box_w = (total_w - 2 * gap) / 3

        x1 = margin
        x2 = x1 + box_w
        x3 = x2 + gap
        x4 = x3 + box_w
        x5 = x4 + gap
        x6 = x5 + box_w

        self.total_box_id = self.canvas.create_rectangle(
            x1, stat_y1, x2, stat_y2,
            fill="#1c1c1c", outline="#d0d0d0", width=1, stipple="gray50",
            tags="ui_static"
        )
        self.anomaly_box_id = self.canvas.create_rectangle(
            x3, stat_y1, x4, stat_y2,
            fill="#1c1c1c", outline="#d0d0d0", width=1, stipple="gray50",
            tags="ui_static"
        )
        self.ratio_box_id = self.canvas.create_rectangle(
            x5, stat_y1, x6, stat_y2,
            fill="#1c1c1c", outline="#d0d0d0", width=1, stipple="gray50",
            tags="ui_static"
        )

        self.canvas.create_text((x1 + x2) / 2, 305, text="Total Flows", fill="white",
                                font=("Arial", 12, "bold"), tags="ui_static")
        self.canvas.create_text((x3 + x4) / 2, 305, text="Anomaly Flows", fill="white",
                                font=("Arial", 12, "bold"), tags="ui_static")
        self.canvas.create_text((x5 + x6) / 2, 305, text="Anomaly Ratio", fill="white",
                                font=("Arial", 12, "bold"), tags="ui_static")

        self.total_value_id = self.canvas.create_text((x1 + x2) / 2, 330, text="0",
                                                      fill="#00e5ff", font=("Arial", 18, "bold"),
                                                      tags="ui_static")
        self.anomaly_value_id = self.canvas.create_text((x3 + x4) / 2, 330, text="0",
                                                        fill="#00e5ff", font=("Arial", 18, "bold"),
                                                        tags="ui_static")
        self.ratio_value_id = self.canvas.create_text((x5 + x6) / 2, 330, text="0.00%",
                                                      fill="#00e5ff", font=("Arial", 18, "bold"),
                                                      tags="ui_static")

        # Bottom panels
        bottom_top = 365
        bottom_bottom = height - 15
        left_w = int(width * 0.68)

        self.log_box_id = self.canvas.create_rectangle(
            15, bottom_top, left_w, bottom_bottom,
            fill="#161616", outline="#d0d0d0", width=1, stipple="gray50",
            tags="ui_static"
        )
        self.ip_box_id = self.canvas.create_rectangle(
            left_w + 12, bottom_top, width - 15, bottom_bottom,
            fill="#161616", outline="#d0d0d0", width=1, stipple="gray50",
            tags="ui_static"
        )

        self.canvas.create_text(
            30, bottom_top + 18,
            text="Real-Time Log",
            fill="white",
            font=("Arial", 14, "bold"),
            anchor="w",
            tags="ui_static"
        )

        self.canvas.create_text(
            left_w + 27, bottom_top + 18,
            text="Recently Blocked / Logged IPs",
            fill="white",
            font=("Arial", 14, "bold"),
            anchor="w",
            tags="ui_static"
        )

    def _create_widgets(self, width, height):
        # Buttons
        self.start_button = tk.Button(
            self.root,
            text="Start Detection",
            font=("Arial", 13, "bold"),
            width=14,
            bg="#2e7d32",
            fg="white",
            activebackground="#388e3c",
            activeforeground="white",
            relief="raised",
            bd=2,
            command=self.start_detection
        )

        self.stop_button = tk.Button(
            self.root,
            text="Stop Detection",
            font=("Arial", 13, "bold"),
            width=14,
            bg="#c62828",
            fg="white",
            activebackground="#d32f2f",
            activeforeground="white",
            relief="raised",
            bd=2,
            state="disabled",
            command=self.stop_detection
        )

        self.clear_button = tk.Button(
            self.root,
            text="Clear Log",
            font=("Arial", 13, "bold"),
            width=14,
            bg="#1565c0",
            fg="white",
            activebackground="#1976d2",
            activeforeground="white",
            relief="raised",
            bd=2,
            command=self.clear_log
        )

        self.start_button_window = self.canvas.create_window(95, 255, window=self.start_button)
        self.stop_button_window = self.canvas.create_window(275, 255, window=self.stop_button)
        self.clear_button_window = self.canvas.create_window(455, 255, window=self.clear_button)

        # Log Text
        self.log_text = tk.Text(
            self.root,
            bg="#050505",
            fg="#00ff88",
            insertbackground="white",
            font=("Consolas", 10),
            wrap="word",
            relief="flat",
            bd=0
        )
        self.log_text_window = self.canvas.create_window(
            30, 405, anchor="nw", window=self.log_text,
            width=int(width * 0.68) - 45,
            height=height - 430
        )

        # IP List
        self.ip_listbox = tk.Listbox(
            self.root,
            bg="#050505",
            fg="white",
            font=("Consolas", 11),
            relief="flat",
            bd=0
        )
        self.ip_listbox_window = self.canvas.create_window(
            int(width * 0.68) + 27, 405, anchor="nw", window=self.ip_listbox,
            width=width - int(width * 0.68) - 55,
            height=height - 430
        )

    # =====================================
    # Resize
    # =====================================
    def on_resize(self, event):
        if event.widget != self.root:
            return

        width = max(self.root.winfo_width(), 1000)
        height = max(self.root.winfo_height(), 650)

        self.canvas.config(width=width, height=height)
        self._draw_background(width, height)
        self._draw_static_ui(width, height)

        # Buttons
        self.canvas.coords(self.start_button_window, 95, 255)
        self.canvas.coords(self.stop_button_window, 275, 255)
        self.canvas.coords(self.clear_button_window, 455, 255)

        # Log / IP widgets
        left_w = int(width * 0.68)
        self.canvas.coords(self.log_text_window, 30, 405)
        self.canvas.itemconfig(
            self.log_text_window,
            width=left_w - 45,
            height=height - 430
        )

        self.canvas.coords(self.ip_listbox_window, left_w + 27, 405)
        self.canvas.itemconfig(
            self.ip_listbox_window,
            width=width - left_w - 55,
            height=height - 430
        )

    # =====================================
    # GUI update helpers
    # =====================================
    def log(self, message):
        timestamp = time.strftime("%H:%M:%S")
        self.gui_queue.put(("log", f"[{timestamp}] {message}"))

    def update_status(self, text, color, detail):
        self.gui_queue.put(("status", text, color, detail))

    def update_stats(self, total_count, anomaly_count, ratio):
        self.gui_queue.put(("stats", total_count, anomaly_count, ratio))

    def add_ips(self, ips):
        self.gui_queue.put(("ips", ips))

    def _update_status_canvas(self, text, color, detail):
        self.canvas.itemconfig(self.status_title_id, text=f"Status: {text}")
        self.canvas.itemconfig(self.status_detail_id, text=detail)
        self.canvas.itemconfig(self.status_box_id, fill=color)

    def process_gui_queue(self):
        try:
            while True:
                item = self.gui_queue.get_nowait()
                kind = item[0]

                if kind == "log":
                    msg = item[1]
                    self.log_text.insert("end", msg + "\n")
                    self.log_text.see("end")

                elif kind == "status":
                    text, color, detail = item[1], item[2], item[3]
                    self._update_status_canvas(text, color, detail)

                elif kind == "stats":
                    total_count, anomaly_count, ratio = item[1], item[2], item[3]
                    self.canvas.itemconfig(self.total_value_id, text=str(total_count))
                    self.canvas.itemconfig(self.anomaly_value_id, text=str(anomaly_count))
                    self.canvas.itemconfig(self.ratio_value_id, text=f"{ratio * 100:.2f}%")

                elif kind == "ips":
                    ips = item[1]
                    current_ips = self.ip_listbox.get(0, "end")
                    for ip in ips:
                        if ip not in current_ips:
                            self.ip_listbox.insert(0, ip)

        except queue.Empty:
            pass

        self.root.after(200, self.process_gui_queue)

    # =====================================
    # XSS target URL scan control
    # =====================================
    def xss_monitor_loop(self):
        self.log("[INFO] XSS target URL monitor started by Start Detection button.")
        self.log(f"[INFO] Target URL file: {TARGET_URL_FILE.resolve()}")
        self.log("[INFO] This method does not use proxy.")
        self.log("[INFO] XSS alert is shown only once per target URL.")

        while self.xss_monitor_running:
            try:
                detected, url, patterns = check_target_url_for_xss(self.log)

                if detected and url:
                    # 같은 URL은 한 번만 경고하고, 이후에는 반복 경고하지 않음
                    if url not in self.xss_alerted_urls:
                        self.xss_alerted_urls.add(url)
                        self.xss_alert_count += 1
                        self.last_xss_state = True

                        self.update_status(
                            "XSS ALERT",
                            XSS_ALERT_COLOR,
                            f"XSS detected from target URL. Total XSS events: {self.xss_alert_count}"
                        )

                        # 오른쪽 blocked/logged 목록에 IP 대신 웹 주소도 표시
                        self.add_ips([url])

                        self.log("=" * 60)
                        self.log("XSS ALERT REGISTERED ONLY ONCE")
                        self.log(f"Blocked / Logged URL: {url}")
                        self.log(f"Patterns: {patterns}")
                        self.log("=" * 60)

                elif not detected:
                    if self.last_xss_state and not self.running:
                        self.update_status(
                            "Normal",
                            "#1f5a2b",
                            "No XSS pattern is currently detected from target URL."
                        )
                    self.last_xss_state = False

            except Exception as e:
                self.log(f"[WARNING] XSS monitor loop failed: {e}")

            for _ in range(XSS_SCAN_INTERVAL * 10):
                if not self.xss_monitor_running:
                    return
                time.sleep(0.1)

    # =====================================
    # CSRF target URL scan control
    # =====================================
    def csrf_monitor_loop(self):
        self.log("[INFO] CSRF target URL monitor started by Start Detection button.")
        self.log(f"[INFO] Target URL file: {TARGET_URL_FILE.resolve()}")
        self.log("[INFO] This CSRF detector checks POST forms without sending POST requests.")
        self.log("[INFO] CSRF alert is shown only once per target URL.")

        while self.csrf_monitor_running:
            try:
                detected, url, findings = check_target_url_for_csrf(self.log)

                if detected and url:
                    if url not in self.csrf_alerted_urls:
                        self.csrf_alerted_urls.add(url)
                        self.csrf_alert_count += 1
                        self.last_csrf_state = True

                        self.update_status(
                            "CSRF ALERT",
                            CSRF_ALERT_COLOR,
                            f"CSRF risk detected from target URL. Total CSRF events: {self.csrf_alert_count}"
                        )

                        self.add_ips([f"CSRF: {url}"])

                        self.log("=" * 60)
                        self.log("CSRF ALERT REGISTERED ONLY ONCE")
                        self.log(f"Logged URL: {url}")
                        self.log(f"Findings: {findings}")
                        self.log(CSRF_ALERT_MESSAGE)
                        self.log("=" * 60)

                elif not detected:
                    if self.last_csrf_state and not self.running:
                        self.update_status(
                            "Normal",
                            "#1f5a2b",
                            "No CSRF risk is currently detected from target URL."
                        )
                    self.last_csrf_state = False

            except Exception as e:
                self.log(f"[WARNING] CSRF monitor loop failed: {e}")

            for _ in range(CSRF_SCAN_INTERVAL * 10):
                if not self.csrf_monitor_running:
                    return
                time.sleep(0.1)


    # =====================================
    # Clickjacking target URL scan control
    # =====================================
    def clickjacking_monitor_loop(self):
        self.log("[INFO] Clickjacking target URL monitor started by Start Detection button.")
        self.log(f"[INFO] Target URL file: {TARGET_URL_FILE.resolve()}")
        self.log("[INFO] This detector checks X-Frame-Options and CSP frame-ancestors headers.")
        self.log("[INFO] Clickjacking alert is shown only once per target URL.")

        while self.clickjacking_monitor_running:
            try:
                detected, url, findings = check_target_url_for_clickjacking(self.log)

                if detected and url:
                    if url not in self.clickjacking_alerted_urls:
                        self.clickjacking_alerted_urls.add(url)
                        self.clickjacking_alert_count += 1
                        self.last_clickjacking_state = True

                        self.update_status(
                            "CLICKJACKING ALERT",
                            CLICKJACKING_ALERT_COLOR,
                            f"Clickjacking risk detected from target URL. Total Clickjacking events: {self.clickjacking_alert_count}"
                        )

                        self.add_ips([f"CLICKJACKING: {url}"])

                        self.log("=" * 60)
                        self.log("CLICKJACKING ALERT REGISTERED ONLY ONCE")
                        self.log(f"Logged URL: {url}")
                        self.log(f"Findings: {findings}")
                        self.log(CLICKJACKING_ALERT_MESSAGE)
                        self.log("=" * 60)

                elif not detected:
                    if self.last_clickjacking_state and not self.running:
                        self.update_status(
                            "Normal",
                            "#1f5a2b",
                            "No Clickjacking risk is currently detected from target URL."
                        )
                    self.last_clickjacking_state = False

            except Exception as e:
                self.log(f"[WARNING] Clickjacking monitor loop failed: {e}")

            for _ in range(CLICKJACKING_SCAN_INTERVAL * 10):
                if not self.clickjacking_monitor_running:
                    return
                time.sleep(0.1)

    # =====================================
    # Button actions
    # =====================================
    def start_detection(self):
        if self.running:
            return

        try:
            ensure_dirs()
            self.model, self.scaler = load_artifacts()

            if AUTO_BLOCK_ENABLED:
                ensure_firewall_setup(self.log)

        except Exception as e:
            messagebox.showerror("Error", str(e))
            return

        self.running = True
        self.xss_alerted_urls.clear()
        self.csrf_alerted_urls.clear()
        self.clickjacking_alerted_urls.clear()
        self.start_button.config(state="disabled")
        self.stop_button.config(state="normal")

        self.log("[INFO] Real-time AI anomaly detection started")
        self.log(f"[INFO] Interface: {INTERFACE}")
        self.log(f"[INFO] Capture duration: {WINDOW_SECONDS} seconds")
        self.log(f"[INFO] Working directory: {WORK_DIR.resolve()}")
        self.log(f"[INFO] cicflowmeter command: {CICFLOWMETER_CMD}")
        self.log(f"[INFO] black_ip.txt path: {BLACKLIST_FILE.resolve()}")
        self.log(f"[INFO] Temporary auto block enabled: {AUTO_BLOCK_ENABLED}")
        self.log(f"[INFO] Temporary block seconds: {TEMP_BLOCK_SECONDS}")

        self.update_status("Running", "#37474f", "Collecting and analyzing live packets.")

        self.worker_thread = threading.Thread(target=self.detection_loop, daemon=True)
        self.worker_thread.start()

        # Start XSS target URL scanner only when detection starts.
        if self.xss_thread is None or not self.xss_thread.is_alive():
            self.xss_monitor_running = True
            self.xss_thread = threading.Thread(target=self.xss_monitor_loop, daemon=True)
            self.xss_thread.start()

        # Start CSRF target URL scanner only when detection starts.
        if self.csrf_thread is None or not self.csrf_thread.is_alive():
            self.csrf_monitor_running = True
            self.csrf_thread = threading.Thread(target=self.csrf_monitor_loop, daemon=True)
            self.csrf_thread.start()

        # Start Clickjacking target URL scanner only when detection starts.
        if self.clickjacking_thread is None or not self.clickjacking_thread.is_alive():
            self.clickjacking_monitor_running = True
            self.clickjacking_thread = threading.Thread(target=self.clickjacking_monitor_loop, daemon=True)
            self.clickjacking_thread.start()

    def stop_detection(self):
        self.running = False
        self.xss_monitor_running = False
        self.csrf_monitor_running = False
        self.clickjacking_monitor_running = False
        self.start_button.config(state="normal")
        self.stop_button.config(state="disabled")
        self.update_status("Stopped", "#5d4037", "Detection has been stopped.")
        self.log("[INFO] Detection stopped by user.")
        self.log("[INFO] XSS target URL monitor stopped.")
        self.log("[INFO] CSRF target URL monitor stopped.")
        self.log("[INFO] Clickjacking target URL monitor stopped.")

    def clear_log(self):
        self.log_text.delete("1.0", "end")

    # =====================================
    # Prediction handling
    # =====================================
    def handle_prediction_result(self, anomaly_df, anomaly_count, total_count, ratio):
        self.update_stats(total_count, anomaly_count, ratio)

        if total_count == 0:
            self.update_status("No Data", "#546e7a", "There is no data to analyze.")
            self.log("[INFO] No data to analyze.")
            return

        if ratio >= 0.5:
            self.update_status(
                "Critical",
                "#8e1b1b",
                "Anomaly ratio is 50% or higher. Critical state detected."
            )

            self.log("=" * 60)
            self.log("CRITICAL WARNING")
            self.log(f"Anomalous flows detected: {anomaly_count} / {total_count}")
            self.log("Warning Warning Warning Warning Warning Warning Warning Warning Warning Warning Warning Warning Warning")
            self.log("=" * 60)

            ips = extract_anomaly_ips(anomaly_df)

            if ips:
                self.log(f"[INFO] Suspicious source IPs detected: {sorted(ips)}")
                new_logged_ips = save_blacklist_log(ips, self.log)
                blocked_ips = temp_block_ips(ips, self.log)

                merged = sorted(set(new_logged_ips) | set(blocked_ips))
                if merged:
                    self.add_ips(merged)
            else:
                self.log("[WARNING] Anomaly ratio is high, but source IP column was not found in the CSV.")

        elif anomaly_count > 0:
            self.update_status(
                "Warning",
                "#9a5a00",
                "Abnormal flows were detected, but the ratio is still below 50%."
            )
            self.log("=" * 60)
            self.log("SYSTEM WARNING")
            self.log(f"Anomalous flows detected: {anomaly_count} / {total_count}")
            self.log("Possible DDoS or abnormal traffic detected.")
            self.log("=" * 60)

        else:
            if not self.last_xss_state and not self.last_csrf_state and not self.last_clickjacking_state:
                self.update_status(
                    "Normal",
                    "#1f5a2b",
                    "No anomaly is currently detected."
                )
            self.log(f"[INFO] No anomaly detected. Normal flows: {total_count}")

    # =====================================
    # Detection loop
    # =====================================
    def detection_loop(self):
        while self.running:
            tag = now_tag()

            pcap_path = RAW_PCAP_DIR / f"capture_{tag}.pcap"
            raw_csv_path = RAW_CSV_DIR / f"flow_{tag}.csv"
            selected_csv_path = SELECTED_CSV_DIR / f"selected_{tag}.csv"
            result_csv_path = RESULT_DIR / f"result_{tag}.csv"

            try:
                ok = capture_pcap(INTERFACE, WINDOW_SECONDS, pcap_path, self.log)
                if not ok:
                    self.log("[INFO] Retrying capture...")
                    for _ in range(SLEEP_BETWEEN_LOOPS * 10):
                        if not self.running:
                            return
                        time.sleep(0.1)
                    continue

                if not self.running:
                    return

                convert_pcap_to_csv(pcap_path, raw_csv_path, self.log)

                raw_df = pd.read_csv(raw_csv_path)
                raw_df.columns = [str(col).strip().lower() for col in raw_df.columns]

                df_selected = select_features(raw_csv_path, selected_csv_path, self.log)

                if df_selected.empty:
                    self.log("[INFO] No usable selected features. Retrying...")
                    for _ in range(SLEEP_BETWEEN_LOOPS * 10):
                        if not self.running:
                            return
                        time.sleep(0.1)
                    continue

                result_df, anomaly_df, anomaly_count, total_count, ratio = predict_with_model(
                    df_selected, raw_df, self.model, self.scaler
                )

                result_df.to_csv(result_csv_path.resolve(), index=False)
                self.log(f"[INFO] prediction result saved -> {result_csv_path.resolve()}")

                self.handle_prediction_result(anomaly_df, anomaly_count, total_count, ratio)

            except Exception as e:
                self.log(f"[ERROR] {e}")
                self.update_status("Error", "#4e342e", str(e))

            for _ in range(SLEEP_BETWEEN_LOOPS * 10):
                if not self.running:
                    return
                time.sleep(0.1)

    def on_close(self):
        self.running = False
        self.xss_monitor_running = False
        self.csrf_monitor_running = False
        self.clickjacking_monitor_running = False
        self.root.destroy()


def main():
    ensure_dirs()

    if not TARGET_URL_FILE.exists():
        TARGET_URL_FILE.write_text("http://127.0.0.1:5000", encoding="utf-8")

    root = tk.Tk()
    app = DDoSDetectorGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
