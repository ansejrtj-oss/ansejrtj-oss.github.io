import joblib
import pandas as pd

scaler = joblib.load("scaler1.pkl")
model = joblib.load("isolation_forest_model1.pkl")

df = pd.read_csv("new_flow1.csv")

X = scaler.transform(df)

result = model.predict(X)

print(result)
