import pandas as pd
import numpy as np
import joblib
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

# -----------------------------
# 1. 파일 경로 설정
# -----------------------------
input_csv = "flows_selected.csv"
scaler_file = "scaler1.pkl"
model_file = "isolation_forest_model1.pkl"

# -----------------------------
# 2. CSV 불러오기
# -----------------------------
df = pd.read_csv(input_csv)

print("데이터 크기:", df.shape)
print("컬럼 목록:")
print(df.columns.tolist())

# -----------------------------
# 3. 숫자형 데이터 확인 및 정리
# -----------------------------
df = df.apply(pd.to_numeric, errors='coerce')
df.replace([np.inf, -np.inf], np.nan, inplace=True)
df.dropna(inplace=True)

print("전처리 후 데이터 크기:", df.shape)

# -----------------------------
# 4. 스케일링
# -----------------------------
scaler = StandardScaler()
X_scaled = scaler.fit_transform(df)

# -----------------------------
# 5. Isolation Forest 학습
# contamination:
# 정상 데이터만 학습할 때
# 대략 0.01 ~ 0.05 사이로 많이 사용
# -----------------------------
model = IsolationForest(
    n_estimators=200,
    contamination=0.03,
    random_state=42,
    n_jobs=-1
)

model.fit(X_scaled)

# -----------------------------
# 6. 학습 데이터에 대해 예측
# 정상: 1
# 이상: -1
# -----------------------------
pred = model.predict(X_scaled)

normal_count = np.sum(pred == 1)
anomaly_count = np.sum(pred == -1)

print("\n학습 결과")
print("정상으로 판단한 개수 :", normal_count)
print("이상으로 판단한 개수 :", anomaly_count)
print("이상 비율 :", anomaly_count / len(pred))

# -----------------------------
# 7. 모델 저장
# -----------------------------
joblib.dump(scaler, scaler_file)
joblib.dump(model, model_file)

print("\n저장 완료")
print(f"스케일러 저장 파일: {scaler_file}")
print(f"모델 저장 파일: {model_file}")
