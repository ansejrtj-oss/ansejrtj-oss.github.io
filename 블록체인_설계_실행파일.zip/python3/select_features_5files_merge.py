import pandas as pd
import numpy as np
from pathlib import Path

# 처리할 5개 CSV 파일 이름
input_files = [
    'DOWNLOAD_0.csv',
    'GAME_0.csv',
    'TALK_0.csv',
    'WEBSURFING_0.csv',
    'YOUTUBE_0.csv'
]

# 최종 합쳐서 저장할 파일 이름
output_file = 'merged_selected_5files.csv'

# 사용할 중요한 feature 목록
important_features = [
    'protocol',
    'flow_duration',
    'flow_byts_s',
    'flow_pkts_s',
    'fwd_pkts_s',
    'bwd_pkts_s',
    'tot_fwd_pkts',
    'tot_bwd_pkts',
    'totlen_fwd_pkts',
    'totlen_bwd_pkts',
    'fwd_pkt_len_mean',
    'bwd_pkt_len_mean',
    'pkt_len_mean',
    'pkt_len_std',
    'pkt_size_avg',
    'flow_iat_mean',
    'flow_iat_std',
    'fwd_iat_mean',
    'bwd_iat_mean',
    'syn_flag_cnt',
    'rst_flag_cnt',
    'psh_flag_cnt',
    'ack_flag_cnt',
    'down_up_ratio',
    'init_fwd_win_byts',
    'init_bwd_win_byts'
]

all_data = []
final_features = None

for file_name in input_files:
    file_path = Path(file_name)

    if not file_path.exists():
        print(f'[건너뜀] 파일 없음: {file_name}')
        continue

    print(f'처리 중: {file_name}')

    # CSV 읽기
    df = pd.read_csv(file_path)

    # 컬럼명 정리
    df.columns = [str(col).strip().lower() for col in df.columns]

    # 실제 존재하는 컬럼만 선택
    existing_features = [f for f in important_features if f in df.columns]

    if not existing_features:
        print(f'[건너뜀] 사용 가능한 feature 없음: {file_name}')
        continue

    # 첫 파일 기준으로 시작하고, 이후 파일들과 공통 feature만 남김
    if final_features is None:
        final_features = existing_features
    else:
        final_features = [f for f in final_features if f in existing_features]

    all_data.append((file_name, df))

if not all_data:
    print('처리할 수 있는 CSV 파일이 없습니다.')
    exit()

if not final_features:
    print('5개 파일 사이에 공통 feature가 없습니다.')
    exit()

processed_frames = []

for file_name, df in all_data:
    df_selected = df[final_features].copy()

    # 숫자형 변환
    df_selected = df_selected.apply(pd.to_numeric, errors='coerce')

    # inf 값 제거
    df_selected = df_selected.replace([np.inf, -np.inf], np.nan)

    # 결측값 처리
    for col in df_selected.columns:
        if df_selected[col].isna().all():
            df_selected[col] = 0
        else:
            df_selected[col] = df_selected[col].fillna(df_selected[col].median())

    processed_frames.append(df_selected)

# 5개 파일 합치기
merged_df = pd.concat(processed_frames, ignore_index=True)

# 저장
merged_df.to_csv(output_file, index=False)

print('완료!')
print(f'처리한 파일 수: {len(processed_frames)}')
print(f'최종 선택된 feature 개수: {len(final_features)}')
print(f'최종 저장 파일: {output_file}')
