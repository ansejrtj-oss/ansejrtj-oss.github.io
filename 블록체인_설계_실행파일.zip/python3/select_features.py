import pandas as pd
import numpy as np

# 입력 CSV 파일
input_file = "new_flow.csv"

# 출력 CSV 파일
output_file = "new_flow1.csv"

# 사용할 중요한 feature 목록
important_features = [
    'protocol',
    'flow_duration',
    'flow_byts_s',
    'flow_pkts_s',
    'fwd_pkts_s',
    'bwd_pkts_s',
    'tot_fwd_pkts',
    'tot_bwd_pkts',
    'totlen_fwd_pkts',
    'totlen_bwd_pkts',
    'fwd_pkt_len_mean',
    'bwd_pkt_len_mean',
    'pkt_len_mean',
    'pkt_len_std',
    'pkt_size_avg',
    'flow_iat_mean',
    'flow_iat_std',
    'fwd_iat_mean',
    'bwd_iat_mean',
    'syn_flag_cnt',
    'rst_flag_cnt',
    'psh_flag_cnt',
    'ack_flag_cnt',
    'down_up_ratio',
    'init_fwd_win_byts',
    'init_bwd_win_byts'
]

# CSV 읽기
df = pd.read_csv(input_file)

# 실제 존재하는 컬럼만 선택
existing_features = [f for f in important_features if f in df.columns]
df_selected = df[existing_features]

# 숫자형으로 변환
df_selected = df_selected.apply(pd.to_numeric, errors='coerce')

# inf 값 제거
df_selected.replace([np.inf, -np.inf], np.nan, inplace=True)

# 결측값을 중앙값으로 채우기
df_selected.fillna(df_selected.median(), inplace=True)

# 저장
df_selected.to_csv(output_file, index=False)

print("완료!")
print(f"선택된 feature 개수: {len(existing_features)}")
print(f"저장된 파일: {output_file}")
