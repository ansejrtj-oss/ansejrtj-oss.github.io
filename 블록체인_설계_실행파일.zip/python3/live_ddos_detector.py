import subprocess
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

# =========================================
# User configuration
# =========================================

INTERFACE = "eth0"
WINDOW_SECONDS = 20
SLEEP_BETWEEN_LOOPS = 1

BASE_DIR = Path(__file__).resolve().parent

MODEL_PATH = BASE_DIR / "isolation_forest_model1.pkl"
SCALER_PATH = BASE_DIR / "scaler1.pkl"

CICFLOWMETER_CMD = "cicflowmeter"

WORK_DIR = BASE_DIR / "live_monitor"
RAW_PCAP_DIR = WORK_DIR / "raw_pcap"
RAW_CSV_DIR = WORK_DIR / "raw_csv"
SELECTED_CSV_DIR = WORK_DIR / "selected_csv"
RESULT_DIR = WORK_DIR / "results"

MIN_PCAP_SIZE = 5000

# Replace this with your actual selected 20 features
IMPORTANT_FEATURES = [
    "protocol",
    "flow_duration",
    "flow_byts_s",
    "flow_pkts_s",
    "fwd_pkts_s",
    "bwd_pkts_s",
    "tot_fwd_pkts",
    "tot_bwd_pkts",
    "totlen_fwd_pkts",
    "totlen_bwd_pkts",
    "fwd_pkt_len_mean",
    "bwd_pkt_len_mean",
    "pkt_len_mean",
    "pkt_len_std",
    "pkt_size_avg",
    "flow_iat_mean",
    "flow_iat_std",
    "fwd_iat_mean",
    "bwd_iat_mean",
    "syn_flag_cnt",
    # 네가 실제 쓴 20개 feature로 여기 맞춰서 수정
]

# =========================================
# Utility functions
# =========================================
def ensure_dirs():
    for d in [WORK_DIR, RAW_PCAP_DIR, RAW_CSV_DIR, SELECTED_CSV_DIR, RESULT_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def now_tag():
    return time.strftime("%Y%m%d_%H%M%S")


def load_artifacts():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"Model file not found: {MODEL_PATH}")
    if not SCALER_PATH.exists():
        raise FileNotFoundError(f"Scaler file not found: {SCALER_PATH}")

    model = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    return model, scaler


# =========================================
# 1. Capture pcap
# =========================================
def capture_pcap(interface: str, duration: int, out_pcap: Path):
    print(f"[INFO] Start capturing on {interface} for {duration} seconds")

    cmd = [
        "timeout", str(duration),
        "tcpdump",
        "-i", interface,
        "-n",
        "not", "arp",
        "-w", str(out_pcap.resolve())
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.stdout.strip():
        print(result.stdout)
    if result.stderr.strip():
        print(result.stderr)

    if result.returncode not in (0, 124):
        raise RuntimeError(
            f"tcpdump execution failed\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )

    if not out_pcap.exists():
        raise RuntimeError("pcap file was not created.")

    pcap_size = out_pcap.stat().st_size
    print(f"[INFO] pcap saved -> {out_pcap.resolve()} ({pcap_size} bytes)")

    if pcap_size < MIN_PCAP_SIZE:
        print("[WARNING] pcap too small, probably no useful traffic")
        return False

    return True


# =========================================
# 2. Convert pcap to raw csv
# =========================================
def convert_pcap_to_csv(pcap_path: Path, csv_path: Path):
    cmd = [
        CICFLOWMETER_CMD,
        "-f",
        str(pcap_path.resolve()),
        "-c",
        str(csv_path.resolve())
    ]

    print(f"[INFO] cicflowmeter conversion started -> {csv_path.name}")
    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.stdout.strip():
        print("[DEBUG] STDOUT:")
        print(result.stdout)

    if result.stderr.strip():
        print("[DEBUG] STDERR:")
        print(result.stderr)

    if result.returncode != 0:
        raise RuntimeError(
            f"cicflowmeter conversion failed\n"
            f"CMD: {' '.join(cmd)}"
        )

    if not csv_path.exists():
        raise RuntimeError("flow CSV file was not created.")

    if csv_path.stat().st_size == 0:
        raise RuntimeError("flow CSV file was created but is empty.")

    print(f"[INFO] raw flow csv saved -> {csv_path.resolve()}")


# =========================================
# 3. Keep only selected features
# =========================================
def select_features(input_csv: Path, output_csv: Path) -> pd.DataFrame:
    df = pd.read_csv(input_csv)

    # Normalize column names
    df.columns = [str(col).strip().lower() for col in df.columns]

    print(f"[DEBUG] raw csv columns: {list(df.columns)}")

    existing_features = [f for f in IMPORTANT_FEATURES if f in df.columns]

    if not existing_features:
        raise RuntimeError("None of the selected features were found in raw CSV.")

    df_selected = df[existing_features].copy()

    # Convert to numeric
    df_selected = df_selected.apply(pd.to_numeric, errors="coerce")

    # Replace inf values
    df_selected = df_selected.replace([np.inf, -np.inf], np.nan)

    # Fill missing values
    for col in df_selected.columns:
        if df_selected[col].isna().all():
            df_selected[col] = 0
        else:
            df_selected[col] = df_selected[col].fillna(df_selected[col].median())

    df_selected.to_csv(output_csv.resolve(), index=False)

    print(f"[INFO] selected feature csv saved -> {output_csv.resolve()}")
    print(f"[INFO] selected feature count: {len(existing_features)}")

    return df_selected


# =========================================
# 4. Align with scaler feature order
# =========================================
def align_features_for_scaler(df_selected: pd.DataFrame, scaler) -> pd.DataFrame:
    if hasattr(scaler, "feature_names_in_"):
        required_features = [str(c).strip().lower() for c in scaler.feature_names_in_]
    else:
        required_features = IMPORTANT_FEATURES

    aligned = df_selected.copy()

    # Add missing columns as 0
    for col in required_features:
        if col not in aligned.columns:
            aligned[col] = 0

    # Keep only required columns in exact order
    aligned = aligned[required_features]
    return aligned


# =========================================
# 5. Predict
# =========================================
def predict_with_model(df_selected: pd.DataFrame, model, scaler):
    X = align_features_for_scaler(df_selected, scaler)
    X_scaled = scaler.transform(X)

    preds = model.predict(X_scaled)
    scores = model.decision_function(X_scaled)

    result_df = X.copy()
    result_df["prediction"] = preds
    result_df["anomaly_score"] = scores
    result_df["label_text"] = result_df["prediction"].map({1: "NORMAL", -1: "ANOMALY"})

    anomaly_count = int((preds == -1).sum())
    total_count = len(result_df)

    return result_df, anomaly_count, total_count


# =========================================
# 6. Print warning
# =========================================
def print_warning_if_needed(anomaly_count: int, total_count: int):
    if anomaly_count > 0:
        print("\n" + "=" * 60)
        print("SYSTEM WARNING")
        print(f"Anomalous flows detected: {anomaly_count} / {total_count}")
        print("Possible DDoS or abnormal traffic detected.")
        print("=" * 60 + "\n")
    else:
        print(f"[INFO] No anomaly detected. Normal flows: {total_count}")


# =========================================
# 7. Main loop
# =========================================
def main():
    ensure_dirs()
    model, scaler = load_artifacts()

    print("[INFO] Real-time AI anomaly detection started")
    print(f"[INFO] Interface: {INTERFACE}")
    print(f"[INFO] Capture duration: {WINDOW_SECONDS} seconds")
    print(f"[INFO] Working directory: {WORK_DIR.resolve()}")
    print(f"[INFO] cicflowmeter command: {CICFLOWMETER_CMD}")

    while True:
        tag = now_tag()

        pcap_path = RAW_PCAP_DIR / f"capture_{tag}.pcap"
        raw_csv_path = RAW_CSV_DIR / f"flow_{tag}.csv"
        selected_csv_path = SELECTED_CSV_DIR / f"selected_{tag}.csv"
        result_csv_path = RESULT_DIR / f"result_{tag}.csv"

        try:
            ok = capture_pcap(INTERFACE, WINDOW_SECONDS, pcap_path)
            if not ok:
                print("[INFO] Retrying capture...")
                time.sleep(SLEEP_BETWEEN_LOOPS)
                continue

            convert_pcap_to_csv(pcap_path, raw_csv_path)

            # Use only your selected features here
            df_selected = select_features(raw_csv_path, selected_csv_path)

            if df_selected.empty:
                print("[INFO] No usable selected features. Retrying...")
                time.sleep(SLEEP_BETWEEN_LOOPS)
                continue

            result_df, anomaly_count, total_count = predict_with_model(df_selected, model, scaler)

            result_df.to_csv(result_csv_path.resolve(), index=False)
            print(f"[INFO] prediction result saved -> {result_csv_path.resolve()}")

            print_warning_if_needed(anomaly_count, total_count)

        except KeyboardInterrupt:
            print("\n[INFO] Program terminated by user.")
            break
        except Exception as e:
            print(f"[ERROR] {e}")

        time.sleep(SLEEP_BETWEEN_LOOPS)


if __name__ == "__main__":
    main()
