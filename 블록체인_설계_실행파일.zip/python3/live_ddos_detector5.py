import subprocess
import time
import ipaddress
import shutil
import threading
import queue
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox

import joblib
import numpy as np
import pandas as pd

# =========================================
# User configuration
# =========================================

INTERFACE = "eth0"
WINDOW_SECONDS = 20
SLEEP_BETWEEN_LOOPS = 1

BASE_DIR = Path(__file__).resolve().parent

MODEL_PATH = BASE_DIR / "isolation_forest_model1.pkl"
SCALER_PATH = BASE_DIR / "scaler1.pkl"

CICFLOWMETER_CMD = "cicflowmeter"

WORK_DIR = BASE_DIR / "live_monitor"
RAW_PCAP_DIR = WORK_DIR / "raw_pcap"
RAW_CSV_DIR = WORK_DIR / "raw_csv"
SELECTED_CSV_DIR = WORK_DIR / "selected_csv"
RESULT_DIR = WORK_DIR / "results"

BLACKLIST_FILE = BASE_DIR / "black_ip.txt"

MIN_PCAP_SIZE = 5000

# Temporary auto-block settings
IPSET_NAME = "temp_blacklist"
TEMP_BLOCK_SECONDS = 300
AUTO_BLOCK_ENABLED = True

IMPORTANT_FEATURES = [
    "protocol",
    "flow_duration",
    "flow_byts_s",
    "flow_pkts_s",
    "fwd_pkts_s",
    "bwd_pkts_s",
    "tot_fwd_pkts",
    "tot_bwd_pkts",
    "totlen_fwd_pkts",
    "totlen_bwd_pkts",
    "fwd_pkt_len_mean",
    "bwd_pkt_len_mean",
    "pkt_len_mean",
    "pkt_len_std",
    "pkt_size_avg",
    "flow_iat_mean",
    "flow_iat_std",
    "fwd_iat_mean",
    "bwd_iat_mean",
    "syn_flag_cnt",
]


# =========================================
# Utility functions
# =========================================
def ensure_dirs():
    for d in [WORK_DIR, RAW_PCAP_DIR, RAW_CSV_DIR, SELECTED_CSV_DIR, RESULT_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def now_tag():
    return time.strftime("%Y%m%d_%H%M%S")


def load_artifacts():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"Model file not found: {MODEL_PATH}")
    if not SCALER_PATH.exists():
        raise FileNotFoundError(f"Scaler file not found: {SCALER_PATH}")

    model = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    return model, scaler


def run_cmd(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


# =========================================
# Firewall / temporary block
# =========================================
def ensure_firewall_setup(log_func):
    global AUTO_BLOCK_ENABLED

    if not AUTO_BLOCK_ENABLED:
        return

    if shutil.which("ipset") is None:
        log_func("[WARNING] ipset is not installed. Auto block disabled.")
        AUTO_BLOCK_ENABLED = False
        return

    if shutil.which("iptables") is None:
        log_func("[WARNING] iptables is not installed. Auto block disabled.")
        AUTO_BLOCK_ENABLED = False
        return

    cmd_create_set = [
        "ipset", "create", IPSET_NAME,
        "hash:ip", "timeout", str(TEMP_BLOCK_SECONDS),
        "-exist"
    ]
    result = run_cmd(cmd_create_set)
    if result.returncode != 0:
        log_func("[WARNING] Failed to create ipset. Auto block disabled.")
        if result.stderr.strip():
            log_func(result.stderr.strip())
        AUTO_BLOCK_ENABLED = False
        return

    cmd_check_rule = [
        "iptables", "-C", "INPUT",
        "-m", "set", "--match-set", IPSET_NAME, "src",
        "-j", "DROP"
    ]
    result = run_cmd(cmd_check_rule)

    if result.returncode != 0:
        cmd_insert_rule = [
            "iptables", "-I", "INPUT", "1",
            "-m", "set", "--match-set", IPSET_NAME, "src",
            "-j", "DROP"
        ]
        result2 = run_cmd(cmd_insert_rule)
        if result2.returncode != 0:
            log_func("[WARNING] Failed to insert iptables rule. Auto block disabled.")
            if result2.stderr.strip():
                log_func(result2.stderr.strip())
            AUTO_BLOCK_ENABLED = False
            return


def is_blockable_ip(ip_str: str) -> bool:
    try:
        ip_obj = ipaddress.ip_address(ip_str)
    except ValueError:
        return False

    if ip_obj.is_loopback:
        return False
    if ip_obj.is_multicast:
        return False
    if ip_obj.is_unspecified:
        return False
    if ip_obj.is_reserved:
        return False

    return True


def temp_block_ips(ips, log_func):
    if not AUTO_BLOCK_ENABLED:
        log_func("[INFO] Auto block is disabled.")
        return []

    blocked = []

    for ip in sorted(ips):
        if not is_blockable_ip(ip):
            continue

        cmd = [
            "ipset", "add", IPSET_NAME, ip,
            "timeout", str(TEMP_BLOCK_SECONDS),
            "-exist"
        ]
        result = run_cmd(cmd)

        if result.returncode == 0:
            blocked.append(ip)
        else:
            log_func(f"[WARNING] Failed to temporarily block IP: {ip}")
            if result.stderr.strip():
                log_func(result.stderr.strip())

    if blocked:
        log_func(f"[INFO] Temporarily blocked {len(blocked)} IP(s) for {TEMP_BLOCK_SECONDS} seconds")
        log_func(f"[INFO] Blocked IP list: {blocked}")
    else:
        log_func("[INFO] No valid IPs were added to temporary block list.")

    return blocked


# =========================================
# Capture / Convert / Predict
# =========================================
def capture_pcap(interface: str, duration: int, out_pcap: Path, log_func):
    log_func(f"[INFO] Start capturing on {interface} for {duration} seconds")

    cmd = [
        "timeout", str(duration),
        "tcpdump",
        "-i", interface,
        "-n",
        "not", "arp",
        "-w", str(out_pcap.resolve())
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.stdout.strip():
        log_func(result.stdout.strip())
    if result.stderr.strip():
        log_func(result.stderr.strip())

    if result.returncode not in (0, 124):
        raise RuntimeError(
            f"tcpdump execution failed\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )

    if not out_pcap.exists():
        raise RuntimeError("pcap file was not created.")

    pcap_size = out_pcap.stat().st_size
    log_func(f"[INFO] pcap saved -> {out_pcap.resolve()} ({pcap_size} bytes)")

    if pcap_size < MIN_PCAP_SIZE:
        log_func("[WARNING] pcap too small, probably no useful traffic")
        return False

    return True


def convert_pcap_to_csv(pcap_path: Path, csv_path: Path, log_func):
    cmd = [
        CICFLOWMETER_CMD,
        "-f",
        str(pcap_path.resolve()),
        "-c",
        str(csv_path.resolve())
    ]

    log_func(f"[INFO] cicflowmeter conversion started -> {csv_path.name}")
    result = subprocess.run(cmd, capture_output=True, text=True)

    if result.stdout.strip():
        log_func("[DEBUG] STDOUT:")
        log_func(result.stdout.strip())

    if result.stderr.strip():
        log_func("[DEBUG] STDERR:")
        log_func(result.stderr.strip())

    if result.returncode != 0:
        raise RuntimeError(
            f"cicflowmeter conversion failed\n"
            f"CMD: {' '.join(cmd)}\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )

    if not csv_path.exists():
        raise RuntimeError("flow CSV file was not created.")

    if csv_path.stat().st_size == 0:
        raise RuntimeError("flow CSV file was created but is empty.")

    log_func(f"[INFO] raw flow csv saved -> {csv_path.resolve()}")


def select_features(input_csv: Path, output_csv: Path, log_func) -> pd.DataFrame:
    df = pd.read_csv(input_csv)

    df.columns = [str(col).strip().lower() for col in df.columns]
    log_func(f"[DEBUG] raw csv columns: {list(df.columns)}")

    existing_features = [f for f in IMPORTANT_FEATURES if f in df.columns]

    if not existing_features:
        raise RuntimeError("None of the selected features were found in raw CSV.")

    df_selected = df[existing_features].copy()

    df_selected = df_selected.apply(pd.to_numeric, errors="coerce")
    df_selected = df_selected.replace([np.inf, -np.inf], np.nan)

    for col in df_selected.columns:
        if df_selected[col].isna().all():
            df_selected[col] = 0
        else:
            df_selected[col] = df_selected[col].fillna(df_selected[col].median())

    df_selected.to_csv(output_csv.resolve(), index=False)

    log_func(f"[INFO] selected feature csv saved -> {output_csv.resolve()}")
    log_func(f"[INFO] selected feature count: {len(existing_features)}")

    return df_selected


def align_features_for_scaler(df_selected: pd.DataFrame, scaler) -> pd.DataFrame:
    if hasattr(scaler, "feature_names_in_"):
        required_features = [str(c).strip().lower() for c in scaler.feature_names_in_]
    else:
        required_features = IMPORTANT_FEATURES

    aligned = df_selected.copy()

    for col in required_features:
        if col not in aligned.columns:
            aligned[col] = 0

    aligned = aligned[required_features]
    return aligned


def predict_with_model(df_selected: pd.DataFrame, raw_df: pd.DataFrame, model, scaler):
    X = align_features_for_scaler(df_selected, scaler)
    X_scaled = scaler.transform(X)

    preds = model.predict(X_scaled)
    scores = model.decision_function(X_scaled)

    result_df = raw_df.copy()
    result_df["prediction"] = preds
    result_df["anomaly_score"] = scores
    result_df["label_text"] = result_df["prediction"].map({1: "NORMAL", -1: "ANOMALY"})

    anomaly_df = result_df[result_df["prediction"] == -1].copy()

    anomaly_count = int((preds == -1).sum())
    total_count = len(result_df)
    ratio = anomaly_count / total_count if total_count > 0 else 0.0

    return result_df, anomaly_df, anomaly_count, total_count, ratio


def extract_anomaly_ips(anomaly_df: pd.DataFrame):
    ips = set()

    possible_src_columns = [
        "src_ip",
        "source_ip",
    ]

    found_col = None
    for col in possible_src_columns:
        if col in anomaly_df.columns:
            found_col = col
            break

    if found_col is None:
        return ips

    values = anomaly_df[found_col].dropna().astype(str).str.strip()

    for ip in values:
        if ip and ip.lower() != "nan":
            ips.add(ip)

    return ips


def save_blacklist_log(ips, log_func):
    existing = set()

    if BLACKLIST_FILE.exists():
        with open(BLACKLIST_FILE, "r", encoding="utf-8") as f:
            existing = {line.strip() for line in f if line.strip()}

    new_ips = ips - existing

    if not new_ips:
        log_func("[INFO] No new suspicious IPs to add to black_ip.txt")
        return []

    with open(BLACKLIST_FILE, "a", encoding="utf-8") as f:
        for ip in sorted(new_ips):
            f.write(ip + "\n")

    log_func(f"[INFO] {len(new_ips)} new IP(s) added to {BLACKLIST_FILE.resolve()}")
    return sorted(new_ips)


# =========================================
# GUI App
# =========================================
class DDoSDetectorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("AI DDoS Detector GUI")
        self.root.geometry("1100x720")
        self.root.minsize(1000, 650)

        self.model = None
        self.scaler = None
        self.running = False
        self.worker_thread = None
        self.gui_queue = queue.Queue()

        self._build_ui()
        self.root.after(200, self.process_gui_queue)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_ui(self):
        self.root.configure(bg="#1e1e1e")

        title = tk.Label(
            self.root,
            text="AI-Based Real-Time DDoS Detection / Temporary Blocking System",
            font=("Arial", 20, "bold"),
            fg="white",
            bg="#1e1e1e"
        )
        title.pack(pady=12)

        top_frame = tk.Frame(self.root, bg="#1e1e1e")
        top_frame.pack(fill="x", padx=12, pady=6)

        left_status = tk.Frame(top_frame, bg="#2b2b2b", bd=2, relief="ridge")
        left_status.pack(side="left", fill="both", expand=True, padx=6)

        right_info = tk.Frame(top_frame, bg="#2b2b2b", bd=2, relief="ridge")
        right_info.pack(side="left", fill="both", expand=True, padx=6)

        self.status_label = tk.Label(
            left_status,
            text="Status: Idle",
            font=("Arial", 18, "bold"),
            fg="white",
            bg="#2b2b2b"
        )
        self.status_label.pack(pady=15)

        self.detail_label = tk.Label(
            left_status,
            text="Normal / Warning / Critical status will be shown here.",
            font=("Arial", 12),
            fg="white",
            bg="#2b2b2b"
        )
        self.detail_label.pack(pady=8)

        info_text = (
            f"Interface: {INTERFACE}\n"
            f"Capture Duration: {WINDOW_SECONDS} sec\n"
            f"Auto Block: {'ON' if AUTO_BLOCK_ENABLED else 'OFF'}\n"
            f"Block Duration: {TEMP_BLOCK_SECONDS} sec\n"
            f"Blacklist File: {BLACKLIST_FILE}"
        )

        self.info_label = tk.Label(
            right_info,
            text=info_text,
            justify="left",
            anchor="w",
            font=("Arial", 12),
            fg="white",
            bg="#2b2b2b"
        )
        self.info_label.pack(fill="both", expand=True, padx=15, pady=15)

        middle_frame = tk.Frame(self.root, bg="#1e1e1e")
        middle_frame.pack(fill="x", padx=12, pady=6)

        self.start_button = tk.Button(
            middle_frame,
            text="Start Detection",
            font=("Arial", 13, "bold"),
            width=14,
            bg="#2e7d32",
            fg="white",
            command=self.start_detection
        )
        self.start_button.pack(side="left", padx=6)

        self.stop_button = tk.Button(
            middle_frame,
            text="Stop Detection",
            font=("Arial", 13, "bold"),
            width=14,
            bg="#c62828",
            fg="white",
            state="disabled",
            command=self.stop_detection
        )
        self.stop_button.pack(side="left", padx=6)

        self.clear_button = tk.Button(
            middle_frame,
            text="Clear Log",
            font=("Arial", 13, "bold"),
            width=14,
            bg="#1565c0",
            fg="white",
            command=self.clear_log
        )
        self.clear_button.pack(side="left", padx=6)

        stats_frame = tk.Frame(self.root, bg="#1e1e1e")
        stats_frame.pack(fill="x", padx=12, pady=6)

        self.total_label = self._make_stat_box(stats_frame, "Total Flows", "0")
        self.total_label.pack(side="left", fill="x", expand=True, padx=6)

        self.anomaly_label = self._make_stat_box(stats_frame, "Anomaly Flows", "0")
        self.anomaly_label.pack(side="left", fill="x", expand=True, padx=6)

        self.ratio_label = self._make_stat_box(stats_frame, "Anomaly Ratio", "0.00%")
        self.ratio_label.pack(side="left", fill="x", expand=True, padx=6)

        bottom_frame = tk.Frame(self.root, bg="#1e1e1e")
        bottom_frame.pack(fill="both", expand=True, padx=12, pady=8)

        log_frame = tk.Frame(bottom_frame, bg="#2b2b2b", bd=2, relief="ridge")
        log_frame.pack(side="left", fill="both", expand=True, padx=6)

        ip_frame = tk.Frame(bottom_frame, bg="#2b2b2b", bd=2, relief="ridge", width=280)
        ip_frame.pack(side="left", fill="y", padx=6)

        log_title = tk.Label(
            log_frame, text="Real-Time Log", font=("Arial", 14, "bold"),
            fg="white", bg="#2b2b2b"
        )
        log_title.pack(anchor="w", padx=10, pady=8)

        self.log_text = tk.Text(
            log_frame,
            bg="#111111",
            fg="#00ff88",
            font=("Consolas", 10),
            wrap="word"
        )
        self.log_text.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        ip_title = tk.Label(
            ip_frame, text="Recently Blocked / Logged IPs", font=("Arial", 14, "bold"),
            fg="white", bg="#2b2b2b"
        )
        ip_title.pack(anchor="w", padx=10, pady=8)

        self.ip_listbox = tk.Listbox(
            ip_frame,
            bg="#111111",
            fg="white",
            font=("Consolas", 11),
            width=32,
            height=25
        )
        self.ip_listbox.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def _make_stat_box(self, parent, title, value):
        frame = tk.Frame(parent, bg="#2b2b2b", bd=2, relief="ridge")
        tk.Label(frame, text=title, font=("Arial", 12, "bold"), fg="white", bg="#2b2b2b").pack(pady=(10, 2))
        value_label = tk.Label(frame, text=value, font=("Arial", 18, "bold"), fg="#00e5ff", bg="#2b2b2b")
        value_label.pack(pady=(2, 10))
        return value_label

    def log(self, message):
        timestamp = time.strftime("%H:%M:%S")
        self.gui_queue.put(("log", f"[{timestamp}] {message}"))

    def update_status(self, text, bg_color, detail):
        self.gui_queue.put(("status", text, bg_color, detail))

    def update_stats(self, total_count, anomaly_count, ratio):
        self.gui_queue.put(("stats", total_count, anomaly_count, ratio))

    def add_ips(self, ips):
        self.gui_queue.put(("ips", ips))

    def process_gui_queue(self):
        try:
            while True:
                item = self.gui_queue.get_nowait()
                kind = item[0]

                if kind == "log":
                    msg = item[1]
                    self.log_text.insert("end", msg + "\n")
                    self.log_text.see("end")

                elif kind == "status":
                    text, bg_color, detail = item[1], item[2], item[3]
                    self.status_label.config(text=f"Status: {text}", bg=bg_color)
                    self.detail_label.config(text=detail, bg=bg_color)
                    for widget in self.status_label.master.winfo_children():
                        widget.config(bg=bg_color)
                    self.status_label.master.config(bg=bg_color)

                elif kind == "stats":
                    total_count, anomaly_count, ratio = item[1], item[2], item[3]
                    self.total_label.config(text=str(total_count))
                    self.anomaly_label.config(text=str(anomaly_count))
                    self.ratio_label.config(text=f"{ratio * 100:.2f}%")

                elif kind == "ips":
                    ips = item[1]
                    for ip in ips:
                        if ip not in self.ip_listbox.get(0, "end"):
                            self.ip_listbox.insert(0, ip)

        except queue.Empty:
            pass

        self.root.after(200, self.process_gui_queue)

    def start_detection(self):
        if self.running:
            return

        try:
            ensure_dirs()
            self.model, self.scaler = load_artifacts()

            if AUTO_BLOCK_ENABLED:
                ensure_firewall_setup(self.log)

        except Exception as e:
            messagebox.showerror("Error", str(e))
            return

        self.running = True
        self.start_button.config(state="disabled")
        self.stop_button.config(state="normal")

        self.log("[INFO] Real-time AI anomaly detection started")
        self.log(f"[INFO] Interface: {INTERFACE}")
        self.log(f"[INFO] Capture duration: {WINDOW_SECONDS} seconds")
        self.log(f"[INFO] Working directory: {WORK_DIR.resolve()}")
        self.log(f"[INFO] cicflowmeter command: {CICFLOWMETER_CMD}")
        self.log(f"[INFO] black_ip.txt path: {BLACKLIST_FILE.resolve()}")
        self.log(f"[INFO] Temporary auto block enabled: {AUTO_BLOCK_ENABLED}")
        self.log(f"[INFO] Temporary block seconds: {TEMP_BLOCK_SECONDS}")

        self.update_status("Running", "#455a64", "Collecting and analyzing live packets.")

        self.worker_thread = threading.Thread(target=self.detection_loop, daemon=True)
        self.worker_thread.start()

    def stop_detection(self):
        self.running = False
        self.start_button.config(state="normal")
        self.stop_button.config(state="disabled")
        self.update_status("Stopped", "#5d4037", "Detection has been stopped.")
        self.log("[INFO] Detection stopped by user.")

    def clear_log(self):
        self.log_text.delete("1.0", "end")

    def handle_prediction_result(self, anomaly_df, anomaly_count, total_count, ratio):
        self.update_stats(total_count, anomaly_count, ratio)

        if total_count == 0:
            self.update_status("No Data", "#546e7a", "There is no data to analyze.")
            self.log("[INFO] No data to analyze.")
            return

        if ratio >= 0.5:
            self.update_status(
                "Critical",
                "#b71c1c",
                "Anomaly ratio is 50% or higher. Critical state detected."
            )

            self.log("=" * 60)
            self.log("CRITICAL WARNING")
            self.log(f"Anomalous flows detected: {anomaly_count} / {total_count}")
            self.log("Warning Warning Warning Warning Warning Warning Warning Warning Warning Warning Warning Warning Warning")
            self.log("=" * 60)

            ips = extract_anomaly_ips(anomaly_df)

            if ips:
                self.log(f"[INFO] Suspicious source IPs detected: {sorted(ips)}")
                new_logged_ips = save_blacklist_log(ips, self.log)
                blocked_ips = temp_block_ips(ips, self.log)

                merged = sorted(set(new_logged_ips) | set(blocked_ips))
                if merged:
                    self.add_ips(merged)
            else:
                self.log("[WARNING] Anomaly ratio is high, but source IP column was not found in the CSV.")

        elif anomaly_count > 0:
            self.update_status(
                "Warning",
                "#ef6c00",
                "Abnormal flows were detected, but the ratio is still below 50%."
            )
            self.log("=" * 60)
            self.log("SYSTEM WARNING")
            self.log(f"Anomalous flows detected: {anomaly_count} / {total_count}")
            self.log("Possible DDoS or abnormal traffic detected.")
            self.log("=" * 60)

        else:
            self.update_status(
                "Normal",
                "#1b5e20",
                "No anomaly is currently detected."
            )
            self.log(f"[INFO] No anomaly detected. Normal flows: {total_count}")

    def detection_loop(self):
        while self.running:
            tag = now_tag()

            pcap_path = RAW_PCAP_DIR / f"capture_{tag}.pcap"
            raw_csv_path = RAW_CSV_DIR / f"flow_{tag}.csv"
            selected_csv_path = SELECTED_CSV_DIR / f"selected_{tag}.csv"
            result_csv_path = RESULT_DIR / f"result_{tag}.csv"

            try:
                ok = capture_pcap(INTERFACE, WINDOW_SECONDS, pcap_path, self.log)
                if not ok:
                    self.log("[INFO] Retrying capture...")
                    for _ in range(SLEEP_BETWEEN_LOOPS * 10):
                        if not self.running:
                            return
                        time.sleep(0.1)
                    continue

                if not self.running:
                    return

                convert_pcap_to_csv(pcap_path, raw_csv_path, self.log)

                raw_df = pd.read_csv(raw_csv_path)
                raw_df.columns = [str(col).strip().lower() for col in raw_df.columns]

                df_selected = select_features(raw_csv_path, selected_csv_path, self.log)

                if df_selected.empty:
                    self.log("[INFO] No usable selected features. Retrying...")
                    for _ in range(SLEEP_BETWEEN_LOOPS * 10):
                        if not self.running:
                            return
                        time.sleep(0.1)
                    continue

                result_df, anomaly_df, anomaly_count, total_count, ratio = predict_with_model(
                    df_selected, raw_df, self.model, self.scaler
                )

                result_df.to_csv(result_csv_path.resolve(), index=False)
                self.log(f"[INFO] prediction result saved -> {result_csv_path.resolve()}")

                self.handle_prediction_result(anomaly_df, anomaly_count, total_count, ratio)

            except Exception as e:
                self.log(f"[ERROR] {e}")
                self.update_status("Error", "#4e342e", str(e))

            for _ in range(SLEEP_BETWEEN_LOOPS * 10):
                if not self.running:
                    return
                time.sleep(0.1)

    def on_close(self):
        self.running = False
        self.root.destroy()


def main():
    root = tk.Tk()
    app = DDoSDetectorGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
